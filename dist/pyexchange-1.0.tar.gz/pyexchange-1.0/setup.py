from distutils.core import setup

setup(
    name="pyexchange",
    version="1.0",
    author="strengthening",
    author_email="strengthen2010@gmail.com",
    packages=["pyexchange", "pyexchange.okex"],
)
